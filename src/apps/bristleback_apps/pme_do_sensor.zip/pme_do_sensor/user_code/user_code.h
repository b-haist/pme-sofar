#include "serial.h"
#include "bsp.h"
#include "debug_configuration.h"

#pragma once

void setup(void);
void loop(void);
